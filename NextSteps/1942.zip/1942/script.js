var container = {};

var hero = { x: 350, y: 300};
var enemies = [ ];
var bullets = [ ];

var escaped = 0;
var score = 0;
var level = 1;



$(document).ready(function(){

  setLevel(0);
  container.height = $('#container').height();
  container.width = $('#container').width();


  // SHOW HERO
  $('#hero').offset({
    top: hero.y,
    left: hero.x
  })

 setInterval(generateEnemies, 3000);
 setInterval(gameLoop, 100);
 setInterval(removeExplosion, 3500);




  $(document).keydown(function(e) {
    var dir = e.keyCode;

    if(dir === 37) {        //LEFT
        hero.x -= 5;
    }
    else if(dir === 38) {   //UP
        hero.y -= 5;
    }
    else if(dir === 39) {   //RIGHT
        hero.x += 5;
    }
    else if(dir === 40) {   //DOWN
        hero.y += 5;
    }

    else if(dir === 32) {   //SPACEBAR
        console.log('fire')
        bullets.push({x: hero.x, y: hero.y});
        displayBullets()
    }


    displayHero()
  });  // END OF KEYDOWN FUNCTION

}); // END OF DOCUMENT READY FUNCTION


function gameLoop() {

  moveEnemies()
  moveBullets()
  detectHit()


}



function displayHero() {
  $('#hero').offset({
    top: hero.y,
    left: hero.x
  })
} // end displayHero


function moveEnemies() {
  for(var i = 0; i < enemies.length; i++) {
    enemies[i].y += enemies[i].speed;

    if(enemies[i].y > container.height) {
      enemies.splice(i, 1)
      escaped++
      $('#escaped').html("escaped " + escaped);
    }
    displayEnemies()
  }
}

function moveBullets() {
  for(var i = bullets.length-1; i >= 0; i--) {
    bullets[i].y -= 10;

    if(bullets[i].y < 0) {
      bullets.splice(i, 1)
    }
    displayBullets()
//    detectHit()
  }
}

function detectHit() {

  for(var i = bullets.length-1; i >= 0; i--) {
    for(var j = bullets.length-1; j >= 0; j--) {

        if( (Math.abs(bullets[i].x - enemies[j].x) < 15) && (Math.abs(bullets[i].y - enemies[j].y) < 10) )  {
          $('#explosion').append('<div class="explosion" style="top:'+enemies[j].y+'px; left:'+enemies[j].x+'px;"></div>');
          bullets.splice(i, 1);
          enemies.splice(j, 1);

          score += 10;
          $('#score').text("Score " + score + " / 40");
          if(score>=10) {
            setLevel()
          }



        }
    }
  }
}


function removeExplosion() {
  $('#bullet0').remove();
  $('.explosion:last-child').fadeOut(4500).remove();

}


function displayEnemies() {

  var hit = false;

  var htmlCode = ""
  for (var i = 0; i < enemies.length; i++) {
    htmlCode += '<div class="enemy'+enemies[i].type+'" style="top:'+enemies[i].y+'px; left:'+enemies[i].x+'px;"></div>';
  }
  $('#enemies').html(htmlCode);
}


function displayBullets() {
  var htmlCode = ""
  for (var i = 0; i < bullets.length; i++) {
    htmlCode += '<div id=bullet'+i+'" class="bullet" style="top:'+bullets[i].y+'px; left:'+bullets[i].x+'px;"></div>';

  }
  $('#bullets').html(htmlCode);
}


function generateEnemies() {

  var randX = Math.round(Math.random()*container.width);
  var randS = Math.round(Math.random()*10);
  var randT = Math.floor(Math.random()*7+1);

  var newEnemy = {
    x: randX,    //RANDOM X POSITION
    y: 0,
    speed: randS,   // RANDOM SPEED
    type: randT
    }

  enemies.push(newEnemy);
}



function setLevel() {



  if(level < 6) {
    $('#container').css('background-image', "url('images/background"+level+".jpg')")
    $('#level').html("Level: " + level)
    score = 0;
    $('#score').text("score " + score + " / 40");
  }
  if(level === 6) {
    alert('you won')
    $('#container').css('background-image', "url('images/background"+level+".jpg')")

  }
  level ++;
}
